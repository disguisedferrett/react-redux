import { TuotetiedotUrl } from './tuotekomponenttiUrl.js';
import { TuotetiedotNumerolla} from './tuotekomponenttiNumerolla.js';