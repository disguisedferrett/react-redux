'use strict';

// console.log(process.argv);

// console.log(process.argv.length);
// console.log(process.argv[2]);

const [,,asetuspolku]=process.argv;
console.log(asetuspolku)

// const [,,...loput]= process.argv;
// console.log(loput);
