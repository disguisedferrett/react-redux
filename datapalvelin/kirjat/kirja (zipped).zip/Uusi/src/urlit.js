const kaikkiUrl = 'http://localhost:3009/kirjat';
const haeYksiUrl = 'http://localhost:3009/kirjat/ehdolla?id=';
const haeYksRestUrl = 'http://localhost:4009/rest/kirjat/';

const kuvaUrl = 'http://localhost:3009/kirjat/kuvat?nimi=';

const lisaysUrlPost = 'http://localhost:3009/rest/kirjat';
const lisaysKuvaUrlPost = 'http://localhost:3009/rest/kirjat/kuvat';

export { kaikkiUrl, haeYksiUrl, haeYksRestUrl, kuvaUrl, lisaysUrlPost, lisaysKuvaUrlPost }