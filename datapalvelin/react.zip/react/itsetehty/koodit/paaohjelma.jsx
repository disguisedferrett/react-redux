import React from 'react';
import ReactDOM from 'react-dom/client';
import Komponentti from './Komponentti';

ReactDOM.createRoot(document.getElementById('juuri')).render(
    <React.StrictMode>
        <Komponentti />
    </React.StrictMode>
)