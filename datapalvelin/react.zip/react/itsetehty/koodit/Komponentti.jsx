function Komponentti(){
    return (
        <h1>Oma appi</h1>
    )
}

export default Komponentti;