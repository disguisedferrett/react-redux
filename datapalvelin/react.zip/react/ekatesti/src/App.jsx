import './App.css'

function App() {
  return (
    <>
      <h1>Hei maailma!</h1>
      <p>Hauskaa päivää!</p>
    </>
  )
}

export default App
