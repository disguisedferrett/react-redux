# JaatelopakastinAPI

## **haeKaikkiLajit()**
palauttaa kaikki jäätelölajit taulukkona

## **onLaji(laji)**
palauttaa `true`, jos laji löytyy, muuten palauttaa `false`

## **haeJaatelo(laji)**
Palauttaa lajia vastaavan jäätelöolion tai `null`, jos lajia ei löydy