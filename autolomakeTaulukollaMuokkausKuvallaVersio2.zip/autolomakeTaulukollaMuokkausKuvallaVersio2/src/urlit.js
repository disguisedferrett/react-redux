const kaikkiUrl = 'http://localhost:3003/autot';
// const haeYksiUrl = 'http://localhost:3003/autot/ehdolla?numero=';
const haeYksRestUrl = 'http://localhost:4003/rest/autot/';

const kuvaUrl = 'http://localhost:3003/autot/kuvat?nimi=';

const lisaysUrlPost = 'http://localhost:4003/rest/autot';
const lisaysKuvaUrlPost = 'http://localhost:4003/rest/autot/kuvat';

export { kaikkiUrl, haeYksRestUrl, kuvaUrl, lisaysUrlPost, lisaysKuvaUrlPost }