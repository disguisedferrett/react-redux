function Kuva({kuvaSrc,nimi}){
    return (
        <img className="Kuva" src={kuvaSrc} alt={nimi} />
    )
}

export default Kuva;