'use strict';

const {STATUSKOODIT, STATUSVIESTIT}=require('./statuskoodit');

const Tietokanta = require('./tietokanta');

const sql = require('./sqlLauseet.json');

const haeKaikki = sql.haeKaikki.join(' ');
const haeSql = sql.hae.join(' ');
const lisaaSql = sql.lisaa.join(' ');
const paivitaSql = sql.paivita.join(' ');
const poistaSql = sql.poista.join(' ');


const PERUSAVAIN = sql.perusavain;

//Tietovarasto

module.exports = class Tietovarasto{
    constructor(){
        this.kanta=new Tietokanta(yhteysoptiot);
    }

    get STATUSKOODIT(){
        return  STATUSKOODIT;
    }

    get resurssi(){
        return 'autot';
    }

    get kuvakansio(){
        return ''; //paranneltava
    }
}